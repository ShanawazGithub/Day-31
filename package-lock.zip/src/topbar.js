import React from 'react'

const Topbar = () => {
    return (
        <nav className="navbar navbar-expand navbar-light bg-primary text-white  topbar mb-4 static-top shadow">

             <h1>Students And Teachers Portal</h1>         
          
        </nav>
    )
}

export default Topbar